# Compatibilidade

O material foi modularizado. Ler CORE.md e os módulos diretos de evals/, operations/, schemas/ e knowledge/ em skills/instructions/references/, conforme a SKILL e o índice. Este ZIP não contém regras ativas e não deve ser usado como acervo.
